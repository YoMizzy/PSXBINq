So what the hell is PSXBINq anyways? And why does this exist? After hours of searching for the right PBP unpacker that gives me the correct .Bin & .Cue files to work on the Playstation Classic, I ended up finding this tiny little exe application called "PSXtract.exe" and you would open up CMD and run some codes to generate some results that Give you the .Bin & .Cue files I so desperately needed to load my USB Thumb drive full of AWESOME Playstation Classics! That little exe did the trick but it wasn't good enough I need more, I needed BETTER. So I started playing around with command lines and finally ended up a totally over the top advanced system of Batch files that automatically takes any EBOOT.PBP file and unpacks and converts them to BIN/CUE files then renames and sends to the "transfer" folder ready to be copied to your USB drive.

Before running "PSXBINq.Bat" you must add you're psp game folders to "PSP/GAME" within root of this directory
Example:"\PSP\GAME\TITLEID001\EBOOT.PBP"
        "\PSP\GAME\TITLEID002\EBOOT.PBP"


From within the PSXBINq application you will have three options to choose from.
 
1) Unpack EBOOT.PBP
2) Delete EBOOT.PBP
3) Exit

Choose Option 1 to Unpack and transfer ALL the PSX EBOOT.PBP files from psx folder.
 
Choose Option 2 to Delete untouched EBOOT.PBP from the downloaded GAME directory. Do you want to Delete the Eboot.PBP? If you Press Y for Yes, this will delete EBOOT.PBP. If you Press N for No, This will keep the untouched EBOOT.PBP.
 
**PSX PBP files are located in "\PSP\GAME\TITLEID\EBOOT.PBP"

Choose Option 3 to Exit PSXBINq.
After Exiting you may copy over the "transfer" folder that contains the Games .BIN & .Cue files to you're USB Thumb drive for Playstation Classic. Works with latest Project Eris or AutoBleem.
 
Hope you find this little tool helpful and feedback is welcomed.
Enjoy,
Mizzy
© 2020 GitHub, Inc.